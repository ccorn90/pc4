About Prolog Connect 4

Prolog Connect 4 incarnates the classic grid-based game using the logic
programming language Prolog.  The current release relies on the Linux
executable gprolog.  If your system does not have gprolog installed,
please visit www.gprolog.org to download and install the package.

To run Prolog Connect 4, simply run the pc4 script in this directory.
